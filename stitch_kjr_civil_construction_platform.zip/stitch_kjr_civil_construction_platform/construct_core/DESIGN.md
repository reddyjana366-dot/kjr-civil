---
name: Construct Core
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#424752'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#727783'
  outline-variant: '#c2c6d4'
  surface-tint: '#005db7'
  primary: '#004d99'
  on-primary: '#ffffff'
  primary-container: '#1565c0'
  on-primary-container: '#dae5ff'
  inverse-primary: '#a9c7ff'
  secondary: '#5d5f5f'
  on-secondary: '#ffffff'
  secondary-container: '#dfe0e0'
  on-secondary-container: '#616363'
  tertiary: '#744200'
  on-tertiary: '#ffffff'
  tertiary-container: '#965700'
  on-tertiary-container: '#ffdfc4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3ff'
  primary-fixed-dim: '#a9c7ff'
  on-primary-fixed: '#001b3d'
  on-primary-fixed-variant: '#00468c'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c7'
  on-secondary-fixed: '#1a1c1c'
  on-secondary-fixed-variant: '#454747'
  tertiary-fixed: '#ffdcbe'
  tertiary-fixed-dim: '#ffb870'
  on-tertiary-fixed: '#2c1600'
  on-tertiary-fixed-variant: '#693c00'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 57px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.25px
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 28px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.5px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 16px
  lg: 24px
  xl: 32px
  container-max: 1280px
  gutter: 24px
---

## Brand & Style

The design system is engineered to bridge the gap between heavy industrial reliability and high-velocity digital efficiency. It targets developers, contractors, and civil engineers who require a platform that feels as sturdy as the infrastructure they build, yet as seamless as a modern consumer application.

The visual style is a refined evolution of **Material Design 3**, leaning into **Corporate / Modern** aesthetics. It prioritizes clarity through generous whitespace, high-quality typography, and a "Safety-First" information hierarchy. The interface avoids unnecessary flourishes, opting instead for functional depth through subtle shadows and deliberate layering to ensure the user feels in total control of complex logistics.

## Colors

This design system utilizes a high-contrast palette to drive action and denote status. 

- **Primary (Royal Blue):** Used for main actions, active states, and brand presence. It conveys authority and technical precision.
- **Secondary (White):** The foundation for all surface areas, ensuring a "clean site" feel.
- **Accent (Orange):** Reserved for highlights, critical notifications, and progress indicators. It draws inspiration from safety vests and high-visibility equipment.
- **Surface (Light Gray):** Used to differentiate background layers from interactive cards and panels.
- **Functional Colors:** Standardized Red and Green are used strictly for error handling and successful "Completion" states in project tracking.

## Typography

The design system utilizes **Plus Jakarta Sans** (as a high-performance alternative to Poppins) to maintain a modern, geometric, and professional tone. 

- **Headlines:** Use Bold or SemiBold weights to create a strong visual anchor for page titles and section headers.
- **Body Text:** Primarily set in 16px for readability in data-heavy environments.
- **Labels:** Used for form field headers, buttons, and status chips.
- **Scaling:** On mobile devices, `display` and `headline-lg` styles should scale down by approximately 15% to ensure they do not break containers.

## Layout & Spacing

The system follows a strict **8px grid** to ensure mathematical harmony across all components.

- **Grid System:** A 12-column fluid grid is used for desktop (breakpoint 1200px+), transitioning to an 8-column grid for tablets (768px - 1199px) and a 4-column grid for mobile (below 768px).
- **Margins:** Desktop views should maintain a minimum of 40px outer margins, while mobile views use 16px.
- **Rhythm:** Vertical spacing between cards and sections should primarily use `lg` (24px) or `xl` (32px) increments to prevent visual clutter and maintain the "Premium" feel.

## Elevation & Depth

Hierarchy is established using **Tonal Layers** combined with **Ambient Shadows**.

- **Level 0 (Background):** Surface color (#F8F9FA). No shadow.
- **Level 1 (Cards/Inputs):** White surface with a very soft, diffused shadow: `0px 2px 8px rgba(21, 101, 192, 0.08)`.
- **Level 2 (Hover/Active):** Slightly more pronounced shadow to indicate interactivity: `0px 8px 16px rgba(21, 101, 192, 0.12)`.
- **Level 3 (Modals/Popovers):** Highest elevation with a deep shadow and a subtle 1px border in a lighter tint of the primary color to define the edge against the background.

## Shapes

The design system adopts a **Rounded** language to soften the industrial nature of the content, making it feel more like a modern startup platform.

- **Standard Elements:** 8px (0.5rem) radius for buttons and small inputs.
- **Large Elements:** 16px (1rem) radius for project cards, containers, and modals (`rounded-lg`).
- **Extra Large:** 24px (1.5rem) radius for top-level layout sections or featured dashboard widgets (`rounded-xl`).

## Components

### Navigation
- **Sticky Navbar:** 72px height, white background with a Level 1 shadow. Links use `label-lg` with the Primary Blue for active states.
- **Role Switcher:** A segmented control or dropdown in the navbar for switching between "Contractor," "Admin," or "Client" views.

### Buttons
- **Primary:** Solid Royal Blue with white text, 8px radius, height 48px.
- **Secondary:** White background with a 1.5px Royal Blue border.
- **Accent:** Solid Orange, reserved exclusively for "Urgent" or "Primary CTA" actions (e.g., "Submit Bid").

### Cards
- **Role-Specific Cards:** 16px padding, 16px border radius. Include a top-aligned icon or avatar and a clear "Status Tracker" footer.
- **Status Trackers:** Horizontal steppers using a 4px height bar. Completed steps are Royal Blue, active steps are Orange, and pending steps are Light Gray.

### Forms
- **Multi-step Forms:** Use a progress bar at the top. Fields should be 56px high (Material 3 style) with 8px radius and a subtle 1px border.
- **Focus State:** 2px solid Royal Blue border with a soft blue outer glow.

### Lists
- **Data Tables:** Clean rows with 1px Light Gray bottom borders. No vertical grid lines. Primary information (e.g., Project Name) is set in `title-md`.